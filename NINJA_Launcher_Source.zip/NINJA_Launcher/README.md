# NINJA Launcher — starter project

A native Kotlin Android launcher foundation.

## Included
- Android HOME / DEFAULT intent filter (so Android can offer it as a home app)
- App discovery and launch
- Search and app drawer
- Clock/date home screen
- Lightweight native Views UI; no third-party runtime libraries

## Build
1. Install Android Studio (Giraffe or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the APK, press the device Home button, then choose NINJA Launcher.

## Notes
- `QUERY_ALL_PACKAGES` is used because a launcher needs to enumerate installed apps. Google Play distribution has package-visibility policy requirements; a sideloaded test build can use this permission subject to Android/device policy.
- This is the first foundation build, not a finished commercial launcher. Widgets, icon packs, wallpaper picker, gestures, backup and deeper customization are planned for later iterations.
