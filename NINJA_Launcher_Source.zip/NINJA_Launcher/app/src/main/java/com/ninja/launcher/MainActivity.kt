package com.ninja.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import android.widget.ImageView
import android.text.Editable
import android.text.TextWatcher
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable

class MainActivity : Activity() {
    private val apps = mutableListOf<ResolveInfo>()
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private lateinit var countLabel: TextView
    private var drawerVisible = false

    private val bg = Color.rgb(16, 20, 38)
    private val accent = Color.rgb(139, 156, 255)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadApps()
        showHome()
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps.clear()
        apps.addAll(packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() })
    }

    private fun showHome() {
        drawerVisible = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(20, 27, 53), Color.rgb(31, 37, 68), Color.rgb(13, 17, 33))
            )
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "NINJA"
            textSize = 15f
            letterSpacing = .22f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
        }
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 25f
            setTextColor(white)
            gravity = Gravity.CENTER
            setOnClickListener { showSettings() }
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(42), 1f))
        top.addView(settings, LinearLayout.LayoutParams(dp(44), dp(42)))
        root.addView(top)

        val clock = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            textSize = 58f
            setTextColor(white)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        val date = TextClock(this).apply {
            format12Hour = "EEEE, d MMMM"
            format24Hour = "EEEE, d MMMM"
            textSize = 14f
            setTextColor(0xFFB9C1DD.toInt())
            gravity = Gravity.CENTER
        }
        val clockWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(42), 0, dp(28))
        }
        clockWrap.addView(clock)
        clockWrap.addView(date)
        root.addView(clockWrap)

        val searchCard = roundedBox(0x22FFFFFF, 24)
        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(0xFFB7BED5.toInt())
            setTextColor(white)
            textSize = 15f
            singleLine = true
            background = null
            setPadding(dp(16), 0, dp(16), 0)
        }
        searchCard.addView(search, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(searchCard)

        val quickTitle = TextView(this).apply {
            text = "YOUR APPS"
            textSize = 11f
            letterSpacing = .18f
            setTextColor(0xFFB7BED5.toInt())
            setPadding(dp(4), dp(26), 0, dp(12))
        }
        root.addView(quickTitle)

        val scroll = ScrollView(this)
        grid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = false
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        countLabel = TextView(this).apply {
            text = "${apps.size} applications"
            textSize = 11f
            setTextColor(0xFF8F99B8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(countLabel)

        val bottom = TextView(this).apply {
            text = "N I N J A   •   APP DRAWER"
            gravity = Gravity.CENTER
            textSize = 11f
            letterSpacing = .08f
            setTextColor(accent)
            background = roundedDrawable(0x22AAB8FF, 30)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setOnClickListener { showDrawer() }
        }
        root.addView(bottom)
        setContentView(root)
        renderApps(apps.take(8))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                val filtered = apps.filter { it.loadLabel(packageManager).toString().lowercase().contains(q) }
                renderApps(filtered.take(8))
                countLabel.text = if (q.isEmpty()) "${apps.size} applications" else "${filtered.size} results"
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun showDrawer() {
        drawerVisible = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(18, 23, 44), Color.rgb(28, 34, 62)))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "All applications"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
        }
        val close = TextView(this).apply {
            text = "⌂"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(accent)
            setOnClickListener { showHome() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(close, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(header)

        val input = EditText(this).apply {
            hint = "Find an application"
            setHintTextColor(0xFFB7BED5.toInt())
            setTextColor(white)
            textSize = 15f
            singleLine = true
            background = roundedDrawable(0x22FFFFFF, 24)
            setPadding(dp(16), 0, dp(16), 0)
        }
        val inputLp = LinearLayout.LayoutParams(-1, dp(52))
        inputLp.setMargins(0, dp(14), 0, dp(12))
        root.addView(input, inputLp)

        val scroll = ScrollView(this)
        grid = GridLayout(this).apply { columnCount = 4 }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        renderApps(apps)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s?.toString()?.trim()?.lowercase().orEmpty()
                renderApps(apps.filter { it.loadLabel(packageManager).toString().lowercase().contains(q) })
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun renderApps(items: List<ResolveInfo>) {
        grid.removeAllViews()
        items.forEach { info ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(8), dp(3), dp(12))
                setOnClickListener { launchApp(info) }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            cell.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)))
            val label = TextView(this).apply {
                text = info.loadLabel(packageManager).toString()
                textSize = 10.5f
                setTextColor(white)
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(0, dp(6), 0, 0)
            }
            cell.addView(label, LinearLayout.LayoutParams(-1, dp(34)))
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            grid.addView(cell, lp)
        }
    }

    private fun launchApp(info: ResolveInfo) {
        val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
        if (launch != null) try { startActivity(launch) } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open this app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        AlertDialog.Builder(this)
            .setTitle("NINJA Launcher")
            .setMessage("Version 1.0\\n\\nThis is the first foundation build. More customization, widgets and themes will be added in the next versions.")
            .setPositiveButton("OK", null)
            .setNeutralButton("Choose default launcher") { _, _ ->
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_HOME_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this, "Open Android Settings > Default apps > Home app", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun roundedBox(color: Int, radius: Int): LinearLayout {
        return LinearLayout(this).apply {
            background = roundedDrawable(color, radius)
            gravity = Gravity.CENTER_VERTICAL
        }
    }

    private fun roundedDrawable(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), 0x22FFFFFF)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
